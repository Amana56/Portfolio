// Form Validation Function
function validateForm() {
  // Retrieve values from form fields
  var name = document.forms["contactForm"]["name"].value;
  var email = document.forms["contactForm"]["email"].value;
  var phone = document.forms["contactForm"]["phone"].value;
  var message = document.forms["contactForm"]["message"].value;

  // Check if any field is empty
  if (name == "" || email == "" || phone == "" || message == "") {
      // Display an alert if any field is empty
      alert("Please fill in all fields");
      // Return false to prevent form submission
      return false;
  }
  // Return true if all fields are filled
  return true;
}

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  // Add event listener to each navigation link
  anchor.addEventListener('click', function(e) {
      // Prevent default behavior of anchor tag
      e.preventDefault();

      // Scroll to the corresponding section of the page
      document.querySelector(this.getAttribute('href')).scrollIntoView({
          behavior: 'smooth' // Smooth scrolling behavior
      });
  });
});
